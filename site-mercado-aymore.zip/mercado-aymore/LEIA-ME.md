# Mercado Aymoré — Site institucional

Site de página única, feito em HTML, CSS e JavaScript puros. Não precisa de servidor,
banco de dados, build ou instalação: basta abrir o `index.html` no navegador ou enviar
a pasta para qualquer hospedagem.

## Estrutura dos arquivos

```
index.html                 → conteúdo e textos do site
assets/css/style.css       → todo o design (cores, tipografia, animações)
assets/js/main.js          → funcionalidades (lista de compras, filtros, carrossel…)
LEIA-ME.md                 → este guia
```

## O que já está funcionando

- **Lista de compras** — o visitante adiciona produtos, ajusta quantidades e envia o
  pedido pronto pelo WhatsApp. A lista fica salva no navegador dele.
- **Filtros por categoria e busca** de produtos, com resposta instantânea.
- **Horário em tempo real** — o site calcula sozinho se a loja está aberta, quanto
  falta para fechar e quando abre novamente. Atualiza a cada minuto.
- **Modo claro e escuro**, com a preferência do visitante memorizada.
- **Carrossel de depoimentos** com setas, indicadores, autoplay e arraste no celular.
- **Formulário de contato** com validação e máscara de telefone; envia pelo WhatsApp.
- **Dúvidas frequentes** em acordeão animado.
- **Mapa do Google** com o endereço real, carregado só quando aparece na tela.
- **Botões de ligar, rota, Instagram e WhatsApp** todos ativos.
- **Animações** de entrada ao rolar, contadores numéricos, faixa deslizante e
  micro-interações — todas leves e desativadas automaticamente para quem usa
  "reduzir movimento" no sistema.

## Como personalizar (o essencial)

Abra `assets/js/main.js`. Tudo que muda de loja para loja está no bloco `CONFIG`,
nas primeiras linhas:

| Campo        | Para que serve                                        |
|--------------|-------------------------------------------------------|
| `whatsapp`   | Número que recebe os pedidos (só números: 55 + DDD)   |
| `telefone`   | Número usado no botão de ligar                        |
| `endereco`   | Endereço exibido e usado nas rotas                    |
| `instagram`  | Link do perfil                                        |
| `horarios`   | Abertura e fechamento de cada dia (0 = domingo)       |
| `produtos`   | Catálogo de ofertas: nome, categoria, preço, emoji    |

Para adicionar um produto, copie uma linha do array `produtos` e troque os valores.
A categoria nova aparece automaticamente nos filtros — não precisa mexer em mais nada.

Cores, arredondamentos e sombras ficam no topo do `style.css`, no bloco `:root`.
Trocar `--brand-500` e `--accent-500` já muda a identidade visual do site inteiro.

## Publicação

1. **Domínio próprio + hospedagem comum:** envie os arquivos por FTP para a pasta
   pública (`public_html`), mantendo a estrutura de pastas.
2. **Netlify / Vercel / Cloudflare Pages:** arraste a pasta para o painel. Publicação
   gratuita e com HTTPS automático.
3. **GitHub Pages:** suba a pasta no repositório e ative o Pages nas configurações.

Depois de publicar, troque a URL da linha `<link rel="canonical">` no `index.html`
pelo domínio real.

## Segurança e boas práticas já aplicadas

- Nenhum dado do visitante é enviado ou armazenado em servidor — o formulário e a
  lista abrem o WhatsApp do próprio usuário.
- Todo texto inserido pela página é escapado antes de ir para o HTML, evitando
  injeção de conteúdo.
- Links externos usam `rel="noopener"`, impedindo que a página aberta acesse a original.
- O mapa é carregado com `loading="lazy"` e `referrerpolicy` restrito.
- A lista salva no navegador é validada contra o catálogo ao carregar, então dados
  alterados manualmente são descartados.
- Sem bibliotecas de terceiros no JavaScript: menos risco e nada para atualizar.

## Acessibilidade e desempenho

- Navegação completa por teclado, com link "pular para o conteúdo" e foco visível.
- Rótulos `aria-*` nos botões de ícone, gaveta e carrossel.
- Animações respeitam `prefers-reduced-motion`.
- Um único arquivo CSS e um único JS, sem imagens pesadas — carregamento rápido
  mesmo em conexão móvel.

## SEO

Título, descrição, Open Graph e dados estruturados de `GroceryStore` já estão no
`index.html`, incluindo endereço, telefone, horários e nota de avaliação. Isso ajuda
o Google a exibir essas informações direto na busca.

---

Textos de depoimentos, preços e números de destaque são exemplos realistas — revise
com o dono da loja antes de publicar.
