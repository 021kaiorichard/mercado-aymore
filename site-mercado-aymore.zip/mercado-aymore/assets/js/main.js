/* ============================================================
   Mercado Aymoré — JavaScript principal
   Sem dependências externas. Tudo roda no navegador do cliente.
   ------------------------------------------------------------
   ÍNDICE
   1.  CONFIG (edite aqui: telefone, endereço, produtos, horários)
   2.  Utilidades
   3.  Preloader e progresso de rolagem
   4.  Cabeçalho, menu mobile e link ativo
   5.  Tema claro/escuro
   6.  Revelação ao rolar + contadores animados
   7.  Faixa (marquee) infinita
   8.  Catálogo: render, filtros e busca
   9.  Lista de compras (gaveta + WhatsApp)
   10. Carrossel de depoimentos
   11. Horário de funcionamento em tempo real
   12. FAQ (acordeão)
   13. Formulário de contato com validação
   14. Voltar ao topo
   ============================================================ */

'use strict';

/* ---------- 1. CONFIG ---------------------------------------
   Tudo que o dono da loja precisa trocar está neste bloco.
------------------------------------------------------------- */
const CONFIG = {
  nome: 'Mercado Aymoré',
  whatsapp: '552137944437',            // só números, com 55 + DDD
  telefone: '+552137944437',
  endereco: 'Estr. da Palhada, 2760 - Riachão, Nova Iguaçu - RJ, 26279-155',
  instagram: 'https://www.instagram.com/mercadoaymore',

  // 0 = domingo … 6 = sábado. null = fechado no dia.
  horarios: {
    0: { abre: 8,  fecha: 14 },
    1: { abre: 7,  fecha: 21 },
    2: { abre: 7,  fecha: 21 },
    3: { abre: 7,  fecha: 21 },
    4: { abre: 7,  fecha: 21 },
    5: { abre: 7,  fecha: 21 },
    6: { abre: 7,  fecha: 21 }
  },

  // Catálogo de ofertas. 'un' aparece ao lado do preço.
  produtos: [
    { id:'p01', nome:'Contra-filé bovino',        cat:'Açougue',   emoji:'🥩', preco:31.90, antes:39.90, un:'kg',  tag:'-20%' },
    { id:'p02', nome:'Coxa e sobrecoxa de frango',cat:'Açougue',   emoji:'🍗', preco:12.49, antes:15.90, un:'kg',  tag:'-21%' },
    { id:'p03', nome:'Linguiça toscana',          cat:'Açougue',   emoji:'🌭', preco:18.90, antes:22.90, un:'kg',  tag:null  },
    { id:'p04', nome:'Tomate italiano',           cat:'Hortifrúti',emoji:'🍅', preco:6.79,  antes:7.99,  un:'kg',  tag:'Fresco' },
    { id:'p05', nome:'Banana prata',              cat:'Hortifrúti',emoji:'🍌', preco:4.99,  antes:6.49,  un:'kg',  tag:'-23%' },
    { id:'p06', nome:'Alface crespa',             cat:'Hortifrúti',emoji:'🥬', preco:2.99,  antes:null,  un:'un',  tag:null  },
    { id:'p07', nome:'Batata inglesa',            cat:'Hortifrúti',emoji:'🥔', preco:4.49,  antes:5.99,  un:'kg',  tag:null  },
    { id:'p08', nome:'Pão francês',               cat:'Padaria',   emoji:'🥖', preco:15.20, antes:16.90, un:'kg',  tag:'Do forno' },
    { id:'p09', nome:'Bolo caseiro de milho',     cat:'Padaria',   emoji:'🍰', preco:18.90, antes:null,  un:'un',  tag:null  },
    { id:'p10', nome:'Queijo mussarela fatiado',  cat:'Frios',     emoji:'🧀', preco:39.90, antes:46.90, un:'kg',  tag:'-15%' },
    { id:'p11', nome:'Presunto cozido',           cat:'Frios',     emoji:'🥓', preco:29.90, antes:34.90, un:'kg',  tag:null  },
    { id:'p12', nome:'Leite integral 1L',         cat:'Mercearia', emoji:'🥛', preco:4.79,  antes:5.49,  un:'un',  tag:null  },
    { id:'p13', nome:'Arroz tipo 1 — 5kg',        cat:'Mercearia', emoji:'🍚', preco:24.90, antes:29.90, un:'un',  tag:'-17%' },
    { id:'p14', nome:'Feijão preto 1kg',          cat:'Mercearia', emoji:'🫘', preco:7.49,  antes:8.99,  un:'un',  tag:null  },
    { id:'p15', nome:'Óleo de soja 900ml',        cat:'Mercearia', emoji:'🫗', preco:6.29,  antes:7.49,  un:'un',  tag:null  },
    { id:'p16', nome:'Café torrado 500g',         cat:'Mercearia', emoji:'☕', preco:16.90, antes:21.90, un:'un',  tag:'-23%' },
    { id:'p17', nome:'Refrigerante 2L',           cat:'Bebidas',   emoji:'🥤', preco:7.99,  antes:9.99,  un:'un',  tag:null  },
    { id:'p18', nome:'Cerveja lata 350ml',        cat:'Bebidas',   emoji:'🍺', preco:3.49,  antes:4.29,  un:'un',  tag:'Gelada' },
    { id:'p19', nome:'Água mineral 1,5L',         cat:'Bebidas',   emoji:'💧', preco:2.99,  antes:null,  un:'un',  tag:null  },
    { id:'p20', nome:'Sabão em pó 1,6kg',         cat:'Limpeza',   emoji:'🧴', preco:18.60, antes:24.90, un:'un',  tag:'-25%' },
    { id:'p21', nome:'Desinfetante 2L',           cat:'Limpeza',   emoji:'🧽', preco:9.90,  antes:12.90, un:'un',  tag:null  },
    { id:'p22', nome:'Papel higiênico 12un',      cat:'Limpeza',   emoji:'🧻', preco:22.90, antes:27.90, un:'pct', tag:'-18%' },
    { id:'p23', nome:'Detergente 500ml',          cat:'Limpeza',   emoji:'🫧', preco:2.79,  antes:3.49,  un:'un',  tag:null  },
    { id:'p24', nome:'Ovos brancos 30un',         cat:'Mercearia', emoji:'🥚', preco:19.90, antes:23.90, un:'bdj', tag:'-16%' }
  ]
};

/* ---------- 2. UTILIDADES ---------- */
const $  = (s, ctx = document) => ctx.querySelector(s);
const $$ = (s, ctx = document) => [...ctx.querySelectorAll(s)];
const brl = n => n.toLocaleString('pt-BR', { style:'currency', currency:'BRL' });
const waLink = texto => 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(texto);
// Escapa texto antes de injetar no HTML (evita qualquer conteúdo indevido)
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const reduzirMovimento = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

function toast(msg, icon = '✅') {
  const box = $('#toasts');
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = '<span>' + icon + '</span><span>' + esc(msg) + '</span>';
  box.appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 2600);
}

/* ---------- 3. PRELOADER + PROGRESSO ---------- */
addEventListener('load', () => {
  setTimeout(() => $('#preloader').classList.add('hidden'), 350);
});

const progress = $('#progress');
function onScrollProgress() {
  const h = document.documentElement;
  const pct = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
  progress.style.width = pct + '%';
  $('#toTop').classList.toggle('show', h.scrollTop > 600);
  $('#header').classList.toggle('is-stuck', h.scrollTop > 6);
}
addEventListener('scroll', onScrollProgress, { passive:true });

/* ---------- 4. CABEÇALHO / MENU / LINK ATIVO ---------- */
const nav = $('#nav');
const burger = $('#burger');
burger.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  burger.textContent = open ? '✕' : '☰';
  burger.setAttribute('aria-expanded', String(open));
});
$$('#nav a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  burger.textContent = '☰';
  burger.setAttribute('aria-expanded', 'false');
}));

// Marca no menu a seção que está na tela
const secoes = $$('main section[id]');
const navObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    const id = e.target.id;
    $$('#nav a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + id));
  });
}, { rootMargin:'-45% 0px -50% 0px' });
secoes.forEach(s => navObserver.observe(s));

/* ---------- 5. TEMA CLARO / ESCURO ---------- */
const themeBtn = $('#themeBtn');
const temaSalvo = localStorage.getItem('aymore-theme');
const temaInicial = temaSalvo || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
aplicarTema(temaInicial);
themeBtn.addEventListener('click', () => {
  aplicarTema(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
});
function aplicarTema(t) {
  document.documentElement.dataset.theme = t;
  themeBtn.textContent = t === 'dark' ? '☀️' : '🌙';
  localStorage.setItem('aymore-theme', t);
}

/* ---------- 6. REVELAÇÃO + CONTADORES ---------- */
const revealObserver = new IntersectionObserver((entries, obs) => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    e.target.classList.add('in');
    obs.unobserve(e.target);
  });
}, { threshold:0.12, rootMargin:'0px 0px -40px 0px' });
$$('[data-reveal]').forEach(el => revealObserver.observe(el));

const countObserver = new IntersectionObserver((entries, obs) => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    animarNumero(e.target);
    obs.unobserve(e.target);
  });
}, { threshold:0.4 });
$$('[data-count]').forEach(el => countObserver.observe(el));

function animarNumero(el) {
  const alvo = parseFloat(el.dataset.count);
  const sufixo = el.dataset.suffix || '';
  const dec = parseInt(el.dataset.decimal || '0', 10);
  if (reduzirMovimento()) { el.textContent = formatarNum(alvo, dec) + sufixo; return; }
  const dur = 1400;
  const t0 = performance.now();
  (function passo(t) {
    const p = Math.min((t - t0) / dur, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = formatarNum(alvo * eased, dec) + sufixo;
    if (p < 1) requestAnimationFrame(passo);
  })(t0);
}
const formatarNum = (n, dec) => dec
  ? n.toFixed(dec).replace('.', ',')
  : Math.round(n).toLocaleString('pt-BR');

/* ---------- 7. MARQUEE INFINITO ---------- */
const marquee = $('#marquee');
if (marquee) marquee.innerHTML += marquee.innerHTML; // duplica para o loop ficar contínuo

/* ---------- 8. CATÁLOGO: RENDER + FILTROS + BUSCA ---------- */
const elProdutos = $('#products');
const elFiltros = $('#filters');
const elBusca = $('#searchInput');
let filtroAtual = 'Todos';
let termoBusca = '';

const categorias = ['Todos', ...new Set(CONFIG.produtos.map(p => p.cat))];
elFiltros.innerHTML = categorias.map((c, i) =>
  '<button class="chip-btn' + (i === 0 ? ' active' : '') + '" data-cat="' + esc(c) + '">' + esc(c) + '</button>'
).join('');

elFiltros.addEventListener('click', e => {
  const btn = e.target.closest('.chip-btn');
  if (!btn) return;
  filtroAtual = btn.dataset.cat;
  $$('.chip-btn', elFiltros).forEach(b => b.classList.toggle('active', b === btn));
  renderProdutos();
});

let debounce;
elBusca.addEventListener('input', () => {
  clearTimeout(debounce);
  debounce = setTimeout(() => { termoBusca = elBusca.value.trim().toLowerCase(); renderProdutos(); }, 180);
});

function renderProdutos() {
  const lista = CONFIG.produtos.filter(p =>
    (filtroAtual === 'Todos' || p.cat === filtroAtual) &&
    (!termoBusca || p.nome.toLowerCase().includes(termoBusca) || p.cat.toLowerCase().includes(termoBusca))
  );

  if (!lista.length) {
    elProdutos.innerHTML = '<div class="empty"><strong>Nenhum produto encontrado.</strong><br>Tente outro termo ou volte para “Todos”.</div>';
    return;
  }

  elProdutos.innerHTML = lista.map((p, i) => {
    const desconto = p.antes ? Math.round((1 - p.preco / p.antes) * 100) : 0;
    const selo = p.tag ? '<span class="badge' + (desconto ? '' : ' badge--green') + '">' + esc(p.tag) + '</span>' : '';
    return '' +
    '<article class="product" style="animation-delay:' + (i * 0.04) + 's">' +
      '<div class="product__media">' + selo + '<em>' + p.emoji + '</em></div>' +
      '<div class="product__body">' +
        '<span class="product__cat">' + esc(p.cat) + '</span>' +
        '<h3 class="product__name">' + esc(p.nome) + '</h3>' +
        '<div class="product__price">' +
          (p.antes ? '<s>' + brl(p.antes) + '</s>' : '') +
          '<b>' + brl(p.preco) + '</b><small>/' + esc(p.un) + '</small>' +
        '</div>' +
        '<button class="btn btn--sm btn--block" data-add="' + p.id + '">+ Adicionar à lista</button>' +
      '</div>' +
    '</article>';
  }).join('');
}

elProdutos.addEventListener('click', e => {
  const btn = e.target.closest('[data-add]');
  if (!btn) return;
  addItem(btn.dataset.add);
});

renderProdutos();

/* ---------- 9. LISTA DE COMPRAS ---------- */
const CHAVE = 'aymore-lista';
let carrinho = carregarCarrinho();

function carregarCarrinho() {
  try {
    const dados = JSON.parse(localStorage.getItem(CHAVE) || '[]');
    // valida contra o catálogo atual: ignora ids desconhecidos
    return Array.isArray(dados)
      ? dados.filter(i => CONFIG.produtos.some(p => p.id === i.id) && Number.isFinite(+i.qtd) && +i.qtd > 0)
             .map(i => ({ id:i.id, qtd:Math.min(99, Math.max(1, Math.round(+i.qtd))) }))
      : [];
  } catch { return []; }
}
const salvarCarrinho = () => localStorage.setItem(CHAVE, JSON.stringify(carrinho));
const acharProduto = id => CONFIG.produtos.find(p => p.id === id);

function addItem(id) {
  const prod = acharProduto(id);
  if (!prod) return;
  const item = carrinho.find(i => i.id === id);
  if (item) item.qtd = Math.min(99, item.qtd + 1);
  else carrinho.push({ id, qtd:1 });
  salvarCarrinho(); pintarCarrinho();
  $('#cartBtn').classList.add('bump');
  setTimeout(() => $('#cartBtn').classList.remove('bump'), 420);
  toast(prod.nome + ' adicionado à lista', '🛒');
}
function mudarQtd(id, delta) {
  const item = carrinho.find(i => i.id === id);
  if (!item) return;
  item.qtd += delta;
  if (item.qtd < 1) carrinho = carrinho.filter(i => i.id !== id);
  salvarCarrinho(); pintarCarrinho();
}

const totalCarrinho = () => carrinho.reduce((s, i) => s + acharProduto(i.id).preco * i.qtd, 0);
const qtdCarrinho = () => carrinho.reduce((s, i) => s + i.qtd, 0);

function pintarCarrinho() {
  const count = $('#cartCount');
  count.textContent = qtdCarrinho();
  count.classList.toggle('show', qtdCarrinho() > 0);
  $('#cartTotal').textContent = brl(totalCarrinho());

  const body = $('#drawerBody');
  if (!carrinho.length) {
    body.innerHTML = '<div class="drawer__empty"><em>🧺</em><strong>Sua lista está vazia</strong><p>Vá até as ofertas e toque em “Adicionar à lista”.</p></div>';
    return;
  }
  body.innerHTML = carrinho.map(i => {
    const p = acharProduto(i.id);
    return '' +
    '<div class="line">' +
      '<div class="line__img">' + p.emoji + '</div>' +
      '<div class="line__info"><strong>' + esc(p.nome) + '</strong><span>' + brl(p.preco) + ' /' + esc(p.un) + '</span></div>' +
      '<div class="qty">' +
        '<button data-qtd="-1" data-id="' + p.id + '" aria-label="Diminuir quantidade">−</button>' +
        '<b>' + i.qtd + '</b>' +
        '<button data-qtd="1" data-id="' + p.id + '" aria-label="Aumentar quantidade">+</button>' +
      '</div>' +
    '</div>';
  }).join('');
}

$('#drawerBody').addEventListener('click', e => {
  const b = e.target.closest('[data-qtd]');
  if (b) mudarQtd(b.dataset.id, parseInt(b.dataset.qtd, 10));
});

// Abrir / fechar gaveta
const drawer = $('#drawer'), overlay = $('#overlay');
function abrirGaveta() {
  drawer.classList.add('open'); overlay.classList.add('open');
  drawer.setAttribute('aria-hidden', 'false');
  document.body.classList.add('no-scroll');
  $('#closeDrawer').focus();
}
function fecharGaveta() {
  drawer.classList.remove('open'); overlay.classList.remove('open');
  drawer.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('no-scroll');
  $('#cartBtn').focus();
}
$('#cartBtn').addEventListener('click', abrirGaveta);
$('#closeDrawer').addEventListener('click', fecharGaveta);
overlay.addEventListener('click', fecharGaveta);
addEventListener('keydown', e => { if (e.key === 'Escape' && drawer.classList.contains('open')) fecharGaveta(); });

$('#clearCart').addEventListener('click', () => {
  if (!carrinho.length) return;
  carrinho = []; salvarCarrinho(); pintarCarrinho();
  toast('Lista limpa', '🧽');
});

$('#sendOrder').addEventListener('click', () => {
  if (!carrinho.length) { toast('Adicione itens antes de enviar', '⚠️'); return; }
  const linhas = carrinho.map(i => {
    const p = acharProduto(i.id);
    return '• ' + i.qtd + 'x ' + p.nome + ' (' + p.un + ') — ' + brl(p.preco * i.qtd);
  });
  const texto =
    'Olá, ' + CONFIG.nome + '! Gostaria de fazer este pedido:\n\n' +
    linhas.join('\n') +
    '\n\nTotal estimado: ' + brl(totalCarrinho()) +
    '\n\nMeu nome: \nEndereço para entrega: \nForma de pagamento: ';
  window.open(waLink(texto), '_blank', 'noopener');
});

pintarCarrinho();

/* ---------- 10. CARROSSEL DE DEPOIMENTOS ---------- */
const track = $('#sliderTrack');
const slides = $$('.slide', track);
const dots = $('#dots');
let idx = 0, autoplay;

dots.innerHTML = slides.map((_, i) =>
  '<button role="tab" class="' + (i ? '' : 'active') + '" data-i="' + i + '" aria-label="Depoimento ' + (i + 1) + '"></button>'
).join('');

function irPara(i) {
  idx = (i + slides.length) % slides.length;
  track.style.transform = 'translateX(' + (-idx * 100) + '%)';
  $$('button', dots).forEach((d, k) => d.classList.toggle('active', k === idx));
}
$('#nextSlide').addEventListener('click', () => { irPara(idx + 1); reiniciarAuto(); });
$('#prevSlide').addEventListener('click', () => { irPara(idx - 1); reiniciarAuto(); });
dots.addEventListener('click', e => {
  const b = e.target.closest('[data-i]');
  if (b) { irPara(+b.dataset.i); reiniciarAuto(); }
});

// Arraste no celular
let x0 = null;
$('#slider').addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive:true });
$('#slider').addEventListener('touchend', e => {
  if (x0 === null) return;
  const dx = e.changedTouches[0].clientX - x0;
  if (Math.abs(dx) > 45) { irPara(idx + (dx < 0 ? 1 : -1)); reiniciarAuto(); }
  x0 = null;
}, { passive:true });

function iniciarAuto() { if (!reduzirMovimento()) autoplay = setInterval(() => irPara(idx + 1), 6000); }
function reiniciarAuto() { clearInterval(autoplay); iniciarAuto(); }
$('#slider').addEventListener('mouseenter', () => clearInterval(autoplay));
$('#slider').addEventListener('mouseleave', iniciarAuto);
iniciarAuto();

/* ---------- 11. HORÁRIO EM TEMPO REAL ---------- */
const DIAS = ['Domingo','Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado'];
const doisDig = n => String(Math.floor(n)).padStart(2, '0') + ':' + String(Math.round((n % 1) * 60)).padStart(2, '0');

function atualizarStatus() {
  const agora = new Date();
  const dia = agora.getDay();
  const hora = agora.getHours() + agora.getMinutes() / 60;
  const hoje = CONFIG.horarios[dia];

  $$('#hoursList li').forEach(li => li.classList.toggle('today', +li.dataset.day === dia));

  const boxTop = $('#topStatus');
  const boxSec = $('#hoursStatus');
  let aberto = false, texto = '';

  if (hoje && hora >= hoje.abre && hora < hoje.fecha) {
    aberto = true;
    const faltam = hoje.fecha - hora;
    texto = faltam <= 1
      ? 'Aberto — fecha em ' + Math.round(faltam * 60) + ' min'
      : 'Aberto agora · fecha às ' + doisDig(hoje.fecha);
  } else {
    // procura a próxima abertura
    for (let i = 0; i < 8; i++) {
      const d = (dia + i) % 7;
      const h = CONFIG.horarios[d];
      if (!h) continue;
      if (i === 0 && hora < h.abre) { texto = 'Fechado · abre hoje às ' + doisDig(h.abre); break; }
      if (i > 0) {
        const quando = i === 1 ? 'amanhã' : DIAS[d].toLowerCase();
        texto = 'Fechado · abre ' + quando + ' às ' + doisDig(h.abre);
        break;
      }
    }
    if (!texto) texto = 'Fechado no momento';
  }

  boxTop.className = 'status' + (aberto ? '' : ' closed');
  boxTop.innerHTML = '<i></i> ' + texto;
  boxSec.textContent = (aberto ? '🟢 ' : '🔴 ') + texto;
  boxSec.style.background = aberto ? 'var(--brand-50)' : 'color-mix(in srgb, var(--accent-500) 12%, transparent)';
}
atualizarStatus();
setInterval(atualizarStatus, 60000); // reavalia a cada minuto

/* ---------- 12. FAQ (ACORDEÃO) ---------- */
$$('#faq .acc').forEach(acc => {
  const q = $('.acc__q', acc), a = $('.acc__a', acc);
  q.addEventListener('click', () => {
    const abrindo = !acc.classList.contains('open');
    // fecha os outros (comportamento de acordeão)
    $$('#faq .acc').forEach(o => {
      o.classList.remove('open');
      $('.acc__a', o).style.maxHeight = '0px';
      $('.acc__q', o).setAttribute('aria-expanded', 'false');
    });
    if (abrindo) {
      acc.classList.add('open');
      a.style.maxHeight = a.scrollHeight + 'px';
      q.setAttribute('aria-expanded', 'true');
    }
  });
});

/* ---------- 13. FORMULÁRIO DE CONTATO ---------- */
const form = $('#contactForm');
form.addEventListener('submit', e => {
  e.preventDefault();
  const nome = $('#nome'), fone = $('#fone'), msg = $('#msg');
  let ok = true;

  const validar = (input, condicao) => {
    const campo = input.closest('.field');
    campo.classList.toggle('invalid', !condicao);
    if (!condicao) ok = false;
  };

  validar(nome, nome.value.trim().length >= 2);
  validar(fone, fone.value.replace(/\D/g, '').length >= 10);
  validar(msg, msg.value.trim().length >= 5);

  if (!ok) { toast('Confira os campos destacados', '⚠️'); return; }

  const texto =
    'Olá, ' + CONFIG.nome + '!\n\n' +
    'Nome: ' + nome.value.trim() + '\n' +
    'Telefone: ' + fone.value.trim() + '\n' +
    'Assunto: ' + $('#assunto').value + '\n\n' +
    msg.value.trim();

  window.open(waLink(texto), '_blank', 'noopener');
  toast('Abrindo o WhatsApp…', '💬');
  form.reset();
});

// Máscara simples de telefone brasileiro
$('#fone').addEventListener('input', e => {
  let v = e.target.value.replace(/\D/g, '').slice(0, 11);
  if (v.length > 6) v = '(' + v.slice(0,2) + ') ' + v.slice(2, v.length === 11 ? 7 : 6) + '-' + v.slice(v.length === 11 ? 7 : 6);
  else if (v.length > 2) v = '(' + v.slice(0,2) + ') ' + v.slice(2);
  else if (v.length) v = '(' + v;
  e.target.value = v;
});

/* Limpa o destaque de erro assim que o usuário corrige */
$$('.field input, .field textarea').forEach(i =>
  i.addEventListener('input', () => i.closest('.field').classList.remove('invalid'))
);

/* ---------- 14. VOLTAR AO TOPO + ANO ---------- */
$('#toTop').addEventListener('click', () =>
  scrollTo({ top:0, behavior: reduzirMovimento() ? 'auto' : 'smooth' })
);
$('#year').textContent = new Date().getFullYear();
onScrollProgress();
